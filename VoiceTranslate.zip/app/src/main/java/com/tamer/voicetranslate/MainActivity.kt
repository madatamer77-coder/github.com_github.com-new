package com.tamer.voicetranslate

import android.Manifest
import android.content.Intent
import android.net.Uri
import java.io.File
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import android.widget.EditText
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

enum class Lang(val label: String, val tag: String, val ml: String) {
    AR("العربية", "ar-SA", TranslateLanguage.ARABIC),
    EN("English", "en-US", TranslateLanguage.ENGLISH),
    SW("Kiswahili", "sw-KE", TranslateLanguage.SWAHILI)
}

data class Msg(val original: String, val translated: String, val side: Int, val target: Lang)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var spA: Spinner
    private lateinit var spB: Spinner
    private lateinit var micA: Button
    private lateinit var micB: Button
    private lateinit var btnNormal: Button
    private lateinit var btnConv: Button
    private lateinit var adapter: MsgAdapter
    private lateinit var input: EditText
    private lateinit var sendA: Button
    private lateinit var sendB: Button
    private var photoUri: Uri? = null
    private var camSrc = Lang.EN
    private var camTgt = Lang.AR
    private val takePhoto =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoUri?.let { readImage(it) }
        }
    private val pickPhoto =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) readImage(uri)
        }

    private val langs = Lang.values()
    private var langA = Lang.AR
    private var langB = Lang.EN
    private var conversation = false

    private var recognizer: SpeechRecognizer? = null
    private var listeningSide = 0       // 0 = idle, 1 = A, 2 = B
    private var pendingSide = 0
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val translators = HashMap<String, Translator>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        status = findViewById(R.id.status)
        spA = findViewById(R.id.spA)
        spB = findViewById(R.id.spB)
        micA = findViewById(R.id.micA)
        micB = findViewById(R.id.micB)
        btnNormal = findViewById(R.id.btnNormal)
        btnConv = findViewById(R.id.btnConv)
        input = findViewById(R.id.input)
        sendA = findViewById(R.id.sendA)
        sendB = findViewById(R.id.sendB)

        adapter = MsgAdapter { speak(it.translated, it.target) }
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            this.adapter = this@MainActivity.adapter
        }

        val labels = langs.map { it.label }
        val sa = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spA.adapter = sa
        spB.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spA.setSelection(langA.ordinal)
        spB.setSelection(langB.ordinal)

        spA.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                langA = langs[pos]
                if (langA == langB) { langB = langs.first { it != langA }; spB.setSelection(langB.ordinal) }
                refreshButtons()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spB.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                langB = langs[pos]
                if (langA == langB) { langA = langs.first { it != langB }; spA.setSelection(langA.ordinal) }
                refreshButtons()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnSwap).setOnClickListener {
            val t = langA; langA = langB; langB = t
            spA.setSelection(langA.ordinal); spB.setSelection(langB.ordinal)
            refreshButtons()
        }
        btnNormal.setOnClickListener { setMode(false) }
        btnConv.setOnClickListener { setMode(true) }
        sendA.setOnClickListener { sendText(1) }
        sendB.setOnClickListener { sendText(2) }
        findViewById<Button>(R.id.btnCam).setOnClickListener { chooseCameraDirection() }
        micA.setOnClickListener { toggleListening(1) }
        micB.setOnClickListener { toggleListening(2) }

        tts = TextToSpeech(this, this)
        setupRecognizer()
        setMode(false)
    }

    // ---------- UI ----------
    private fun setMode(conv: Boolean) {
        conversation = conv
        btnNormal.alpha = if (conv) 0.5f else 1f
        btnConv.alpha = if (conv) 1f else 0.5f
        micB.visibility = if (conv) View.VISIBLE else View.GONE
        sendB.visibility = if (conv) View.VISIBLE else View.GONE
        refreshButtons()
    }

    private fun refreshButtons() {
        micA.text = "🎤 ${langA.label}"
        micB.text = "🎤 ${langB.label}"
        sendA.text = "ترجم\n${langA.label}"
        sendB.text = "ترجم\n${langB.label}"
        paint(micA, if (listeningSide == 1) "#C62828" else "#1B5E20")
        paint(micB, if (listeningSide == 2) "#C62828" else "#0D47A1")
    }

    private fun paint(b: Button, color: String) {
        b.setTextColor(Color.WHITE)
        b.background = GradientDrawable().apply {
            cornerRadius = 36f; setColor(Color.parseColor(color))
        }
    }

    private fun setStatus(s: String) { status.text = s }

    // ---------- Speech to text ----------
    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("خدمة التعرف على الصوت غير متوفرة على هذا الجهاز")
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { setStatus("تكلم الآن...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { setStatus("جاري المعالجة...") }
                override fun onError(error: Int) {
                    val side = listeningSide
                    listeningSide = 0; refreshButtons()
                    if (side != 0) setStatus(
                        when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH,
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ما سمعتش كلام، جرب تاني"
                            SpeechRecognizer.ERROR_NETWORK,
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "مشكلة في الإنترنت"
                            else -> "حصل خطأ في التعرف على الصوت ($error)"
                        }
                    )
                }
                override fun onPartialResults(partial: Bundle?) {
                    val t = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) setStatus(t)
                }
                override fun onEvent(t: Int, b: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    val side = listeningSide
                    listeningSide = 0; refreshButtons()
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (side != 0 && !text.isNullOrBlank()) process(text, side)
                }
            })
        }
    }

    private fun toggleListening(side: Int) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSide = side
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        val r = recognizer ?: return
        tts.stop()
        if (listeningSide == side) { r.stopListening(); return }
        if (listeningSide != 0) r.cancel()

        listeningSide = side
        refreshButtons()
        val lang = if (side == 1) langA else langB
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang.tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingSide != 0) toggleListening(pendingSide)
        } else setStatus("لازم تسمح باستخدام الميكروفون")
        pendingSide = 0
    }

    // ---------- Translation ----------
    private fun translator(s: Lang, t: Lang): Translator =
        translators.getOrPut("${s.ml}-${t.ml}") {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(s.ml).setTargetLanguage(t.ml).build()
            )
        }

    private fun process(text: String, side: Int) {
        val src = if (side == 1) langA else langB
        val tgt = if (side == 1) langB else langA
        translateAndAdd(text, src, tgt, side, true)
    }

    private fun translateAndAdd(text: String, src: Lang, tgt: Lang, side: Int, speakIt: Boolean) {
        val tr = translator(src, tgt)
        setStatus("جاري الترجمة... (أول مرة بيتحمل ملف اللغة)")
        tr.downloadModelIfNeeded()
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { out ->
                        adapter.add(Msg(text, out, side, tgt))
                        findViewById<RecyclerView>(R.id.list).scrollToPosition(adapter.itemCount - 1)
                        setStatus("تمت الترجمة")
                        if (speakIt) speak(out, tgt)
                    }
                    .addOnFailureListener { setStatus("فشلت الترجمة: ${it.message}") }
            }
            .addOnFailureListener { setStatus("فشل تحميل ملف اللغة، تأكد من الإنترنت") }
    }

    // ---------- Typed text ----------
    private fun sendText(side: Int) {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.text.clear()
        process(t, side)
    }

    // ---------- Camera ----------
    private fun chooseCameraDirection() {
        val items = arrayOf(
            "النص مكتوب بـ ${langB.label} ← ترجمة إلى ${langA.label}",
            "النص مكتوب بـ ${langA.label} ← ترجمة إلى ${langB.label}"
        )
        AlertDialog.Builder(this).setTitle("اتجاه الترجمة").setItems(items) { _, i ->
            if (i == 0) { camSrc = langB; camTgt = langA } else { camSrc = langA; camTgt = langB }
            if (camSrc == Lang.AR) {
                Toast.makeText(
                    this,
                    "قراءة النص العربي من الصورة غير مدعومة حاليًا. الكاميرا تقرأ الإنجليزي والسواحيلي.",
                    Toast.LENGTH_LONG
                ).show()
            } else chooseImageSource()
        }.show()
    }

    private fun chooseImageSource() {
        AlertDialog.Builder(this).setItems(arrayOf("📷 تصوير بالكاميرا", "🖼 اختيار صورة من المعرض")) { _, i ->
            if (i == 0) {
                val dir = File(cacheDir, "images").apply { mkdirs() }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dir, "shot.jpg"))
                photoUri = uri
                takePhoto.launch(uri)
            } else pickPhoto.launch("image/*")
        }.show()
    }

    private fun readImage(uri: Uri) {
        setStatus("جاري قراءة النص من الصورة...")
        try {
            val img = InputImage.fromFilePath(this, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
                .addOnSuccessListener { r ->
                    val t = r.text.trim()
                    if (t.isEmpty()) setStatus("ما لقيتش نص في الصورة")
                    else translateAndAdd(t, camSrc, camTgt, 3, false)
                }
                .addOnFailureListener { setStatus("فشلت قراءة الصورة: ${it.message}") }
        } catch (e: Exception) {
            setStatus("تعذر فتح الصورة")
        }
    }

    // ---------- Text to speech ----------
    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { runOnUiThread { micA.isEnabled = false; micB.isEnabled = false } }
            override fun onDone(id: String?) { runOnUiThread { micA.isEnabled = true; micB.isEnabled = true } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { runOnUiThread { micA.isEnabled = true; micB.isEnabled = true } }
        })
    }

    private fun speak(text: String, lang: Lang) {
        if (!ttsReady) return
        val r = tts.setLanguage(Locale.forLanguageTag(lang.tag))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(
                this, "صوت ${lang.label} غير مثبت. نزله من إعدادات الجهاز > تحويل النص إلى كلام",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        translators.values.forEach { it.close() }
        super.onDestroy()
    }
}

// ---------- Chat list ----------
class MsgAdapter(private val onTap: (Msg) -> Unit) : RecyclerView.Adapter<MsgAdapter.VH>() {
    private val items = ArrayList<Msg>()

    fun add(m: Msg) { items.add(m); notifyItemInserted(items.size - 1) }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val bubble: LinearLayout = v.findViewById(R.id.bubble)
        val original: TextView = v.findViewById(R.id.original)
        val translated: TextView = v.findViewById(R.id.translated)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_message, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]
        h.original.text = m.original
        h.translated.text = m.translated
        val color = when (m.side) { 1 -> "#DCEFDC"; 2 -> "#D6E4F7"; else -> "#FFF3CD" }
        h.bubble.background = GradientDrawable().apply {
            cornerRadius = 32f; setColor(Color.parseColor(color))
        }
        val lp = h.bubble.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (m.side == 1) android.view.Gravity.END else android.view.Gravity.START
        h.bubble.layoutParams = lp
        h.bubble.setOnClickListener { onTap(m) }
    }
}
